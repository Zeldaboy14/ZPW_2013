SceneNavi
=========

A level editor for The Legend of Zelda: Ocarina of Time, written in C#.

Requirements
============

* .NET Framework 4
* OpenTK (currently uses opentk-2012-03-15)
* QuickFont
* Nini 1.1.0
